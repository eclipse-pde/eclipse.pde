import java.io.File;
import java.net.URL;

import org.eclipse.core.boot.BootLoader;

public class SlimLauncher {

	public static void main(String[] args) throws Exception {
		if (args.length > 2) {
			String app= args[0];
			File pluginsFile= new File(args[1]);
			String[] newArgs= new String[args.length - 2];
			System.arraycopy(args, 2, newArgs, 0, args.length - 2);
			BootLoader.run(app, pluginsFile.toURL(), null, newArgs);
		} else {
			System.exit(1);
		}
	}
}

