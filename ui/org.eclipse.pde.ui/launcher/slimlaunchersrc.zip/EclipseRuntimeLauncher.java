import java.io.File;
import java.net.URL;

import org.eclipse.core.boot.BootLoader;

public class EclipseRuntimeLauncher {

	public static void main(String[] args) throws Exception {
		if (args.length > 2) {
			String app = args[0];
			File pluginsFile = new File(args[1]);
			String[] newArgs = new String[args.length - 2];
			System.arraycopy(args, 2, newArgs, 0, args.length - 2);
			int result = 0;
/*
			do {
				Object robj = BootLoader.run(app, pluginsFile.toURL(), null, newArgs);
				if (robj != null && robj instanceof Integer) {
					result = ((Integer) robj).intValue();
				} else
					result = 0;
			} while (result == 23);
*/
			Object robj = BootLoader.run(app, pluginsFile.toURL(), null, newArgs);
			if (robj != null && robj instanceof Integer) {
				result = ((Integer) robj).intValue();
			} else
				result = 0;
			System.exit(result);
		} else {
			System.exit(1);
		}
	}
}