package tests.apiusescan.coretestproject;

public class TestInterfaceImpl implements ITestInterface {

	public Integer fField = new Integer(100);
	
	public Integer performTask() {
		return fField;

	}

}
