package tests.apiusescan.coretestproject;

public interface ITestInterface {

	public Integer performTask();
}
