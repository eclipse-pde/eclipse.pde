package tests.apiusescan.coretestproject;

public interface IConstants {

	public static final Integer CONSTANT = new Integer(10);
}
