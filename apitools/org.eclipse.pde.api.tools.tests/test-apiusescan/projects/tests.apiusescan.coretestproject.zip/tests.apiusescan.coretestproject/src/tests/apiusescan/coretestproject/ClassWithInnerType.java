package tests.apiusescan.coretestproject;

public class ClassWithInnerType {

	public class InnerType {
		
		public int getTen(){
			return 10;
		}
	};
	
	
}
